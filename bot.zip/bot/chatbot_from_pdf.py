import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# تحميل نموذج الذكاء الاصطناعي
model = SentenceTransformer('sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2')

# --- تحميل ملف PDF واستخراج الجمل ---
pdf_sentences = []

def extract_sentences_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text()
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    return lines

# --- حساب التشابه والإجابة ---
def get_best_answer(question, sentences, model, top_k=1, context_lines=2):
    question_embedding = model.encode([question])
    sentence_embeddings = model.encode(sentences)
    similarities = cosine_similarity(question_embedding, sentence_embeddings)[0]
    best_idx = similarities.argmax()
    start = best_idx
    end = min(best_idx + context_lines + 1, len(sentences))
    response = "\n".join(sentences[start:end])
    return response

# --- تحميل PDF ---
def load_pdf():
    global pdf_sentences
    file_path = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf")])
    if file_path:
        sentences = extract_sentences_from_pdf(file_path)
        if sentences:
            pdf_sentences = sentences
            messagebox.showinfo("تم", "✅ تم تحميل الملف وتحليله بنجاح")
        else:
            messagebox.showwarning("تحذير", "⚠️ لم يتم استخراج أي نصوص من الملف.")

# --- سؤال المستخدم ---
def ask_question():
    global pdf_sentences
    question = question_entry.get()
    if not pdf_sentences:
        messagebox.showwarning("تحذير", "رجاءً حمّل ملف PDF أولًا")
        return
    answer = get_best_answer(question, pdf_sentences, model)
    answer_text.delete(1.0, tk.END)
    answer_text.insert(tk.END, answer)

# --- واجهة المستخدم ---
root = tk.Tk()
root.title("🤖 شات بوت ذكي من PDF")
root.geometry("700x500")
root.configure(bg="#e0f7fa")  # خلفية سماوية

style_font = ("Arial", 12, "bold")

# زر التحميل
load_button = tk.Button(root, text="📂 تحميل ملف PDF", command=load_pdf,
                        bg="#0288d1", fg="white", font=style_font, width=25, height=2)
load_button.pack(pady=10)

# تسمية السؤال
question_label = tk.Label(root, text="❓ اكتب سؤالك:", bg="#e0f7fa", font=("Arial", 11))
question_label.pack()

# حقل إدخال السؤال
question_entry = tk.Entry(root, width=60, font=("Arial", 11))
question_entry.pack(pady=5)

# زر السؤال
ask_button = tk.Button(root, text="اسأل ➤", command=ask_question,
                       bg="#00796b", fg="white", font=style_font, width=20, height=2)
ask_button.pack(pady=10)

# مربع عرض الإجابة
answer_text = scrolledtext.ScrolledText(root, width=80, height=12, wrap=tk.WORD, font=("Arial", 11), bg="#ffffff")
answer_text.pack(padx=10, pady=10)

root.mainloop()

